#include <iostream>
#include <queue>
#include <vector>

using namespace std;

void bfs(vector<vector<int> >& adjList, int startNode, vector<bool>& visited){
    
}

void addEdge(vector<vector<int> >& adjList, int u, int v){
    
}

void printAdjacencyList(const vector<vector<int>>& adjList){
    
}

int main()
{
    int vertices = 5;

    vector<vector<int> > adjList(vertices);


    return 0;
}

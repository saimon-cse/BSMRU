#include <iostream>
#include <vector>

using namespace std;

void addEdge(vector<vector<int>>& adjList, int u, int v) {
    
}

void printAdjacencyList(const vector<vector<int>>& adjList) {
  
}

int main() {
    
    int vertices = 5;

    vector<vector<int>> adjList(vertices);


    return 0;
}

#include <iostream>
#include <queue>
#include <vector>

using namespace std;

void bfs(vector<vector<int>>& adjMatrix, int startNode, vector<bool>& visited){
   
}

void addEdge(vector<vector<int>>& adjMatrix, int u, int v){
    
}

void printAdjacencyMatrix(const vector<vector<int>>& adjMatrix){
    
}


int main()
{
    int vertices = 5;

    vector<vector<int>> adjMatrix(vertices, vector<int>(vertices, 0));


    return 0;
}


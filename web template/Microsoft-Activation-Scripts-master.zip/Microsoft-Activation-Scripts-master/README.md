<p align="center"><img src="https://massgrave.dev/img/logo_small.png" alt="MAS Logo"></p>

<h1 align="center">Microsoft  Activation  Scripts (MAS)</h1>

<p align="center">A Windows and Office activator using HWID / Ohook / KMS38 / Online KMS activation methods, with a focus on open-source code and fewer antivirus detections.</p>

<p align="center">
    <a href="https://discord.gg/tVFN4N84PP"><img src="https://img.shields.io/discord/746721520931569757?style=social&logo=discord" alt="Chat with us without signup" title="Chat with us without signup"></a>
    <a href="https://www.reddit.com/r/MAS_Activator"><img src="https://img.shields.io/badge/MAS%20on%20Reddit--orange?style=social&logo=reddit" alt="MAS on Reddit" title="MAS on Reddit"></a>
    <a href="https://twitter.com/massgravel"><img src="https://img.shields.io/twitter/follow/massgravel" alt="Follow us on X" title="Follow us on X"></a>
</p>

<hr>

## Download / How to use it?

### Method 1 - PowerShell (Recommended)

-   Right-click on the Windows start menu and select PowerShell or Terminal (Not CMD).
-   Copy-paste the below code and press enter
    ```
    irm https://massgrave.dev/get | iex
    ```
-   You will see the activation options. Follow the on-screen instructions.
-   That's all.

### Method 2 - Traditional

-   Download the file from [GitHub](https://github.com/massgravel/Microsoft-Activation-Scripts/archive/refs/heads/master.zip) or [Bitbucket](https://bitbucket.org/WindowsAddict/microsoft-activation-scripts/get/master.zip)
-   Right-click on the downloaded zip file and extract
-   In the extracted folder, find the folder named `All-In-One-Version`
-   Run the file named `MAS_AIO.cmd`
-   You will see the activation options. Follow the on-screen instructions.
-   That's all.

To run the scripts in unattended mode, check [here](https://massgrave.dev/command_line_switches)

</br>

```
Latest Version: 2.6
Release date: 20-Apr-2024
```

### [Troubleshooting / Help](https://massgrave.dev/troubleshoot)
### [Download Original Windows & Office](https://massgrave.dev/genuine-installation-media)
### Homepage - [https://massgrave.dev/](https://massgrave.dev/)

---

<p align="center">Made with Love ❤️</p>
